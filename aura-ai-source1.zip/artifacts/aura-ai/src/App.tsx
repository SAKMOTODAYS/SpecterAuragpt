import { useEffect, useState, useRef, useCallback } from "react";
import { useAuth } from "@workspace/replit-auth-web";
import { useQueryClient } from "@tanstack/react-query";
import {
  useListGeminiConversations,
  getListGeminiConversationsQueryKey,
  useCreateGeminiConversation,
  useDeleteGeminiConversation,
  useListGeminiMessages,
  getListGeminiMessagesQueryKey,
} from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useTheme } from "@/hooks/use-theme";
import { Moon, Sun, Plus, LogOut, Trash2, ArrowUp, MessageSquare } from "lucide-react";

type Message = {
  id: string;
  role: "user" | "assistant";
  content: string;
  streaming?: boolean;
};

const SUGGESTIONS = [
  "Explain quantum computing simply",
  "Write a Python function to sort a list",
  "What are the best productivity habits?",
  "Help me brainstorm a startup idea",
  "Summarize the history of the internet",
  "Give me a creative writing prompt",
];

function StreamingDots() {
  return (
    <span className="inline-flex items-center space-x-1 py-1">
      <span className="w-1.5 h-1.5 rounded-full bg-current streaming-dot" />
      <span className="w-1.5 h-1.5 rounded-full bg-current streaming-dot" />
      <span className="w-1.5 h-1.5 rounded-full bg-current streaming-dot" />
    </span>
  );
}

function Markdown({ content }: { content: string }) {
  const html = content
    .replace(/```(\w*)\n?([\s\S]*?)```/g, (_, lang, code) =>
      `<pre><code class="language-${lang || "text"}">${code
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")}</code></pre>`
    )
    .replace(/`([^`]+)`/g, "<code>$1</code>")
    .replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>")
    .replace(/\*(.+?)\*/g, "<em>$1</em>")
    .replace(/^### (.+)$/gm, "<h3>$1</h3>")
    .replace(/^## (.+)$/gm, "<h2>$1</h2>")
    .replace(/^# (.+)$/gm, "<h1>$1</h1>")
    .replace(/^- (.+)$/gm, "<li>$1</li>")
    .replace(/(<li>.*<\/li>)/gs, "<ul>$1</ul>")
    .replace(/\n\n/g, "</p><p>")
    .replace(/\n/g, "<br />");
  return (
    <div
      className="prose prose-sm dark:prose-invert"
      dangerouslySetInnerHTML={{ __html: `<p>${html}</p>` }}
    />
  );
}

// ── Root ────────────────────────────────────────────────────────────────────

export default function App() {
  const { user, isLoading, isAuthenticated, login, logout } = useAuth();

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="flex space-x-1.5">
          <div className="w-2 h-2 rounded-full bg-primary streaming-dot" />
          <div className="w-2 h-2 rounded-full bg-primary streaming-dot" />
          <div className="w-2 h-2 rounded-full bg-primary streaming-dot" />
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return <LoginScreen onLogin={login} />;
  }

  // Profile is resolved from the authenticated user object (DB-backed).
  // If firstName is missing the user needs to complete setup.
  if (!user?.firstName) {
    return <ProfileSetup user={user} onComplete={() => window.location.reload()} />;
  }

  return <MainChat user={user} onLogout={logout} />;
}

// ── Login ────────────────────────────────────────────────────────────────────

function LoginScreen({ onLogin }: { onLogin: () => void }) {
  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <div className="max-w-md w-full text-center space-y-8 animate-in fade-in zoom-in duration-500">
        <div className="flex justify-center">
          <div className="w-20 h-20 rounded-2xl brand-gradient flex items-center justify-center shadow-2xl shadow-primary/30">
            <svg width="36" height="36" viewBox="0 0 36 36" fill="none">
              <circle cx="18" cy="18" r="10" stroke="white" strokeWidth="2" opacity="0.5" />
              <circle cx="18" cy="18" r="5" fill="white" />
              <path d="M18 4L18 8M18 28L18 32M4 18L8 18M28 18L32 18" stroke="white" strokeWidth="2" strokeLinecap="round" opacity="0.6" />
            </svg>
          </div>
        </div>
        <div className="space-y-3">
          <h1 className="text-5xl font-bold tracking-tight brand-text">AuraAI</h1>
          <p className="text-muted-foreground text-base leading-relaxed">
            Your intelligent AI companion, powered by Gemini.
          </p>
        </div>
        <Button
          onClick={onLogin}
          size="lg"
          className="px-10 rounded-full h-12 brand-gradient text-white border-0 shadow-lg shadow-primary/30 hover:opacity-90 transition-all duration-200 text-base font-medium"
        >
          Continue with Replit
        </Button>
        <p className="text-xs text-muted-foreground">Free to use — your chats are always saved.</p>
      </div>
    </div>
  );
}

// ── Profile Setup ─────────────────────────────────────────────────────────────

function ProfileSetup({ user, onComplete }: { user: any; onComplete: () => void }) {
  const [name, setName] = useState(user?.firstName || "");
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const avatar =
    user?.profileImageUrl ||
    `https://api.dicebear.com/7.x/initials/svg?seed=${encodeURIComponent(name || "A")}`;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;
    setSaving(true);
    setError("");
    try {
      const res = await fetch("/api/auth/user", {
        method: "PATCH",
        credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ firstName: name.trim() }),
      });
      if (!res.ok) throw new Error("Failed to save profile");
      onComplete();
    } catch {
      setError("Could not save profile. Please try again.");
      setSaving(false);
    }
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <form
        onSubmit={handleSubmit}
        className="max-w-sm w-full space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500"
      >
        <div className="text-center space-y-2">
          <h1 className="text-3xl font-bold">Welcome to AuraAI</h1>
          <p className="text-muted-foreground">Let's set up your profile.</p>
        </div>
        <div className="space-y-6">
          <div className="flex justify-center">
            <div className="relative">
              <img
                src={avatar}
                alt="Avatar"
                className="w-24 h-24 rounded-full object-cover ring-2 ring-primary/30 ring-offset-2 ring-offset-background"
              />
            </div>
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium">Display Name</label>
            <Input
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="h-12 bg-input/50 border-border/50 focus-visible:ring-primary"
              placeholder="How should I call you?"
              autoFocus
              maxLength={100}
            />
            {error && <p className="text-xs text-destructive">{error}</p>}
          </div>
          <Button
            type="submit"
            size="lg"
            className="w-full h-12 rounded-full brand-gradient text-white border-0 shadow-lg shadow-primary/25 hover:opacity-90 transition-opacity"
            disabled={!name.trim() || saving}
          >
            {saving ? "Saving..." : "Start Chatting"}
          </Button>
        </div>
      </form>
    </div>
  );
}

// ── Main Chat ─────────────────────────────────────────────────────────────────

function MainChat({ user, onLogout }: { user: any; onLogout: () => void }) {
  const { theme, toggleTheme } = useTheme();
  const queryClient = useQueryClient();
  const [activeConvId, setActiveConvId] = useState<number | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [streaming, setStreaming] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const abortRef = useRef<AbortController | null>(null);

  const { data: conversations } = useListGeminiConversations();
  const { data: convMessages } = useListGeminiMessages(activeConvId!, {
    query: {
      enabled: !!activeConvId,
      queryKey: getListGeminiMessagesQueryKey(activeConvId!),
    },
  });
  const createConversation = useCreateGeminiConversation();
  const deleteConversation = useDeleteGeminiConversation();

  const displayName = user?.firstName || "there";
  const avatarUrl =
    user?.profileImageUrl ||
    `https://api.dicebear.com/7.x/initials/svg?seed=${encodeURIComponent(displayName)}`;

  useEffect(() => {
    if (convMessages) {
      setMessages(
        convMessages.map((m: any) => ({
          id: String(m.id),
          role: m.role as "user" | "assistant",
          content: m.content,
        }))
      );
    }
  }, [convMessages]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const autoResize = () => {
    const el = textareaRef.current;
    if (!el) return;
    el.style.height = "auto";
    el.style.height = Math.min(el.scrollHeight, 200) + "px";
  };

  const sendMessage = useCallback(async () => {
    const text = input.trim();
    if (!text || streaming) return;

    setInput("");
    if (textareaRef.current) textareaRef.current.style.height = "auto";

    const userMsg: Message = { id: `u-${Date.now()}`, role: "user", content: text };
    setMessages((prev) => [...prev, userMsg]);
    setStreaming(true);

    let convId = activeConvId;

    try {
      // Create conversation if needed
      if (!convId) {
        const newConv = await createConversation.mutateAsync({
          data: { title: text.slice(0, 60) },
        });
        convId = (newConv as any).id;
        setActiveConvId(convId!);
        queryClient.invalidateQueries({ queryKey: getListGeminiConversationsQueryKey() });
      }

      const assistantId = `a-${Date.now()}`;
      setMessages((prev) => [
        ...prev,
        { id: assistantId, role: "assistant", content: "", streaming: true },
      ]);

      abortRef.current = new AbortController();
      const res = await fetch(`/api/gemini/conversations/${convId}/messages`, {
        method: "POST",
        credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ content: text }),
        signal: abortRef.current.signal,
      });

      if (!res.ok) throw new Error(`HTTP ${res.status}`);

      const reader = res.body!.getReader();
      const decoder = new TextDecoder();
      let buf = "";

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buf += decoder.decode(value, { stream: true });
        const lines = buf.split("\n");
        buf = lines.pop() ?? "";
        for (const line of lines) {
          if (!line.startsWith("data: ")) continue;
          try {
            const data = JSON.parse(line.slice(6));
            if (data.content) {
              setMessages((prev) =>
                prev.map((m) =>
                  m.id === assistantId ? { ...m, content: m.content + data.content } : m
                )
              );
            }
            if (data.error) {
              setMessages((prev) =>
                prev.map((m) =>
                  m.id === assistantId
                    ? { ...m, content: data.error, streaming: false }
                    : m
                )
              );
            }
            if (data.done) {
              setMessages((prev) =>
                prev.map((m) =>
                  m.id === assistantId ? { ...m, streaming: false } : m
                )
              );
              queryClient.invalidateQueries({ queryKey: getListGeminiConversationsQueryKey() });
              queryClient.invalidateQueries({ queryKey: getListGeminiMessagesQueryKey(convId!) });
            }
          } catch (_) {}
        }
      }
    } catch (err: any) {
      if (err?.name !== "AbortError") {
        setMessages((prev) =>
          prev.map((m) =>
            m.streaming
              ? { ...m, streaming: false, content: m.content || "Something went wrong. Please try again." }
              : m
          )
        );
      }
    } finally {
      setStreaming(false);
    }
  }, [input, streaming, activeConvId, createConversation, queryClient]);

  const selectConv = (id: number) => {
    if (streaming) abortRef.current?.abort();
    setActiveConvId(id);
    setMessages([]);
    setSidebarOpen(false);
  };

  const newChat = () => {
    if (streaming) abortRef.current?.abort();
    setActiveConvId(null);
    setMessages([]);
    setInput("");
    setSidebarOpen(false);
  };

  const deleteConv = async (e: React.MouseEvent, id: number) => {
    e.stopPropagation();
    try {
      await deleteConversation.mutateAsync({ id });
      queryClient.invalidateQueries({ queryKey: getListGeminiConversationsQueryKey() });
      if (activeConvId === id) { setActiveConvId(null); setMessages([]); }
    } catch (_) {}
  };

  const convList = (conversations ?? []) as any[];

  const sidebar = (
    <div className="flex flex-col h-full bg-sidebar">
      <div className="p-4 flex items-center justify-between shrink-0">
        <span className="font-bold brand-text text-lg">AuraAI</span>
        <Button
          variant="ghost"
          size="icon"
          onClick={newChat}
          className="text-sidebar-foreground/70 hover:text-sidebar-foreground h-8 w-8"
          title="New chat"
        >
          <Plus size={18} />
        </Button>
      </div>

      <div className="px-3 pb-2 shrink-0">
        <p className="text-[10px] uppercase tracking-widest text-muted-foreground font-semibold px-1">
          Recents
        </p>
      </div>

      <div className="flex-1 overflow-y-auto px-2 space-y-0.5">
        {convList.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-32 text-muted-foreground/50 text-sm">
            <MessageSquare size={24} className="mb-2 opacity-40" />
            <span>No conversations yet</span>
          </div>
        ) : (
          [...convList].reverse().map((conv) => (
            <div
              key={conv.id}
              role="button"
              tabIndex={0}
              onClick={() => selectConv(conv.id)}
              onKeyDown={(e) => e.key === "Enter" && selectConv(conv.id)}
              className={`group w-full text-left px-3 py-2.5 rounded-lg text-sm transition-colors flex items-center justify-between gap-2 cursor-pointer ${
                activeConvId === conv.id
                  ? "bg-sidebar-accent text-sidebar-accent-foreground"
                  : "text-sidebar-foreground/80 hover:bg-sidebar-accent/60 hover:text-sidebar-foreground"
              }`}
            >
              <span className="truncate">{conv.title || "Untitled"}</span>
              <button
                type="button"
                onClick={(e) => deleteConv(e, conv.id)}
                className="opacity-0 group-hover:opacity-100 text-muted-foreground hover:text-destructive shrink-0 transition-opacity p-0.5"
              >
                <Trash2 size={13} />
              </button>
            </div>
          ))
        )}
      </div>

      <div className="p-3 border-t border-sidebar-border shrink-0">
        <div className="flex items-center gap-2 px-1">
          <img
            src={avatarUrl}
            alt={displayName}
            className="w-7 h-7 rounded-full object-cover shrink-0"
          />
          <span className="text-sm font-medium truncate flex-1 text-sidebar-foreground">
            {displayName}
          </span>
          <button
            onClick={onLogout}
            className="text-muted-foreground hover:text-foreground transition-colors p-1"
            title="Sign out"
          >
            <LogOut size={14} />
          </button>
        </div>
      </div>
    </div>
  );

  return (
    <div className="flex h-screen overflow-hidden bg-background">
      {/* Desktop sidebar */}
      <div className="w-[260px] shrink-0 hidden md:block border-r border-sidebar-border">
        {sidebar}
      </div>

      {/* Mobile sidebar overlay */}
      {sidebarOpen && (
        <div className="fixed inset-0 z-50 md:hidden flex">
          <div className="w-[260px] shrink-0 border-r border-sidebar-border shadow-xl">
            {sidebar}
          </div>
          <div className="flex-1 bg-black/40" onClick={() => setSidebarOpen(false)} />
        </div>
      )}

      {/* Main chat area */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Header */}
        <div className="h-14 shrink-0 border-b border-border/50 flex items-center px-4 justify-between">
          <button
            className="md:hidden text-muted-foreground hover:text-foreground transition-colors p-1"
            onClick={() => setSidebarOpen(true)}
          >
            <svg width="20" height="20" viewBox="0 0 20 20" fill="currentColor">
              <rect x="2" y="4" width="16" height="2" rx="1" />
              <rect x="2" y="9" width="16" height="2" rx="1" />
              <rect x="2" y="14" width="16" height="2" rx="1" />
            </svg>
          </button>
          <div className="flex items-center gap-3 ml-auto">
            <div className="flex items-center gap-2 px-3 py-1.5 bg-muted rounded-full text-xs font-medium">
              <span className="w-2 h-2 rounded-full bg-primary shadow-[0_0_8px_hsl(256,86%,70%)]" />
              <span>Gemini 2.5</span>
            </div>
            <button
              onClick={toggleTheme}
              className="text-muted-foreground hover:text-foreground transition-colors p-1.5"
            >
              {theme === "dark" ? <Sun size={17} /> : <Moon size={17} />}
            </button>
          </div>
        </div>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto">
          {messages.length === 0 ? (
            <WelcomeScreen
              name={displayName}
              onSuggestion={(s) => {
                setInput(s);
                textareaRef.current?.focus();
              }}
            />
          ) : (
            <div className="max-w-3xl mx-auto px-4 py-6 space-y-6">
              {messages.map((msg) => (
                <div
                  key={msg.id}
                  className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}
                >
                  {msg.role === "assistant" && (
                    <div className="w-7 h-7 rounded-full brand-gradient shrink-0 mr-3 mt-0.5 shadow-sm shadow-primary/20" />
                  )}
                  <div
                    className={`max-w-[85%] ${
                      msg.role === "user"
                        ? "bg-input rounded-2xl rounded-tr-sm px-4 py-3 text-sm"
                        : "text-sm leading-relaxed"
                    }`}
                  >
                    {msg.role === "assistant" ? (
                      msg.streaming && msg.content === "" ? (
                        <StreamingDots />
                      ) : (
                        <Markdown content={msg.content} />
                      )
                    ) : (
                      <span className="whitespace-pre-wrap">{msg.content}</span>
                    )}
                    {msg.streaming && msg.content !== "" && (
                      <span className="inline-block w-0.5 h-4 bg-current ml-0.5 animate-pulse align-middle" />
                    )}
                  </div>
                </div>
              ))}
              <div ref={messagesEndRef} />
            </div>
          )}
        </div>

        {/* Input */}
        <div className="shrink-0 px-4 pb-4 pt-2 w-full max-w-3xl mx-auto">
          <div className="relative bg-input rounded-2xl shadow-sm border border-border/40 focus-within:border-primary/40 focus-within:shadow-primary/10 focus-within:shadow-md transition-all duration-200">
            <Textarea
              ref={textareaRef}
              value={input}
              onChange={(e) => { setInput(e.target.value); autoResize(); }}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault();
                  sendMessage();
                }
              }}
              placeholder="Message AuraAI..."
              rows={1}
              className="resize-none rounded-2xl bg-transparent border-0 focus-visible:ring-0 pr-12 py-4 pl-4 text-sm min-h-[56px] max-h-[200px]"
              disabled={streaming}
            />
            <button
              onClick={sendMessage}
              disabled={!input.trim() || streaming}
              className="absolute right-2.5 bottom-2.5 w-9 h-9 rounded-xl brand-gradient flex items-center justify-center transition-all duration-200 disabled:opacity-30 hover:opacity-90 shadow-md shadow-primary/20 text-white disabled:cursor-not-allowed"
            >
              <ArrowUp size={16} strokeWidth={2.5} />
            </button>
          </div>
          <p className="text-center mt-2 text-[11px] text-muted-foreground/60">
            AuraAI can make mistakes. Verify important information.
          </p>
        </div>
      </div>
    </div>
  );
}

// ── Welcome ───────────────────────────────────────────────────────────────────

function WelcomeScreen({
  name,
  onSuggestion,
}: {
  name: string;
  onSuggestion: (s: string) => void;
}) {
  return (
    <div className="flex-1 flex flex-col items-center justify-center px-4 py-12 text-center">
      <div className="w-16 h-16 rounded-2xl brand-gradient flex items-center justify-center mb-6 shadow-xl shadow-primary/25">
        <svg width="28" height="28" viewBox="0 0 28 28" fill="none">
          <circle cx="14" cy="14" r="7" stroke="white" strokeWidth="1.5" opacity="0.6" />
          <circle cx="14" cy="14" r="3.5" fill="white" />
          <path
            d="M14 3L14 6M14 22L14 25M3 14L6 14M22 14L25 14"
            stroke="white"
            strokeWidth="1.5"
            strokeLinecap="round"
            opacity="0.5"
          />
        </svg>
      </div>
      <h2 className="text-2xl font-semibold mb-1">Hi {name}, how can I help you?</h2>
      <p className="text-muted-foreground text-sm mb-8">Ask me anything — I'm here to help.</p>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 max-w-xl w-full">
        {SUGGESTIONS.map((s) => (
          <button
            key={s}
            onClick={() => onSuggestion(s)}
            className="text-left px-4 py-3 rounded-xl border border-border/60 bg-card/50 text-sm text-muted-foreground hover:text-foreground hover:border-primary/30 hover:bg-card transition-all duration-150"
          >
            {s}
          </button>
        ))}
      </div>
    </div>
  );
}
