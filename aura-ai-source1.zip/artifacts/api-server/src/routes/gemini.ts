import { Router, type Request, type Response } from "express";
import { db } from "@workspace/db";
import { conversations as conversationsTable, messages as messagesTable } from "@workspace/db";
import { ai } from "@workspace/integrations-gemini-ai";
import { eq, asc } from "drizzle-orm";

const router = Router();

// ── helpers ────────────────────────────────────────────────────────────────

function requireAuth(req: Request, res: Response): string | null {
  if (!req.isAuthenticated()) {
    res.status(401).json({ error: "Unauthorized" });
    return null;
  }
  return req.user.id;
}

function parseId(raw: string): number | null {
  const n = Number(raw);
  return Number.isInteger(n) && n > 0 ? n : null;
}

async function getOwnedConversation(id: number, userId: string) {
  const [conv] = await db
    .select()
    .from(conversationsTable)
    .where(eq(conversationsTable.id, id));
  if (!conv || conv.userId !== userId) return null;
  return conv;
}

// ── routes ─────────────────────────────────────────────────────────────────

router.get("/gemini/conversations", async (req, res) => {
  const userId = requireAuth(req, res);
  if (!userId) return;

  try {
    const rows = await db
      .select()
      .from(conversationsTable)
      .where(eq(conversationsTable.userId, userId))
      .orderBy(asc(conversationsTable.createdAt));
    res.json(rows);
  } catch (err) {
    req.log.error({ err }, "Failed to list conversations");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/gemini/conversations", async (req, res) => {
  const userId = requireAuth(req, res);
  if (!userId) return;

  const title = typeof req.body?.title === "string" ? req.body.title.trim().slice(0, 200) : null;
  if (!title) {
    res.status(400).json({ error: "title is required and must be a non-empty string" });
    return;
  }

  try {
    const [conv] = await db
      .insert(conversationsTable)
      .values({ userId, title })
      .returning();
    res.status(201).json(conv);
  } catch (err) {
    req.log.error({ err }, "Failed to create conversation");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/gemini/conversations/:id", async (req, res) => {
  const userId = requireAuth(req, res);
  if (!userId) return;

  const id = parseId(req.params.id);
  if (!id) { res.status(400).json({ error: "Invalid conversation id" }); return; }

  try {
    const conv = await getOwnedConversation(id, userId);
    if (!conv) { res.status(404).json({ error: "Conversation not found" }); return; }

    const msgs = await db
      .select()
      .from(messagesTable)
      .where(eq(messagesTable.conversationId, id))
      .orderBy(asc(messagesTable.createdAt));

    res.json({ ...conv, messages: msgs });
  } catch (err) {
    req.log.error({ err }, "Failed to get conversation");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.delete("/gemini/conversations/:id", async (req, res) => {
  const userId = requireAuth(req, res);
  if (!userId) return;

  const id = parseId(req.params.id);
  if (!id) { res.status(400).json({ error: "Invalid conversation id" }); return; }

  try {
    const conv = await getOwnedConversation(id, userId);
    if (!conv) { res.status(404).json({ error: "Conversation not found" }); return; }

    // messages cascade-delete via FK, but delete explicitly for safety
    await db.delete(messagesTable).where(eq(messagesTable.conversationId, id));
    await db.delete(conversationsTable).where(eq(conversationsTable.id, id));
    res.status(204).send();
  } catch (err) {
    req.log.error({ err }, "Failed to delete conversation");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/gemini/conversations/:id/messages", async (req, res) => {
  const userId = requireAuth(req, res);
  if (!userId) return;

  const id = parseId(req.params.id);
  if (!id) { res.status(400).json({ error: "Invalid conversation id" }); return; }

  try {
    const conv = await getOwnedConversation(id, userId);
    if (!conv) { res.status(404).json({ error: "Conversation not found" }); return; }

    const msgs = await db
      .select()
      .from(messagesTable)
      .where(eq(messagesTable.conversationId, id))
      .orderBy(asc(messagesTable.createdAt));

    res.json(msgs);
  } catch (err) {
    req.log.error({ err }, "Failed to list messages");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/gemini/conversations/:id/messages", async (req, res) => {
  const userId = requireAuth(req, res);
  if (!userId) return;

  const id = parseId(req.params.id);
  if (!id) { res.status(400).json({ error: "Invalid conversation id" }); return; }

  const content = typeof req.body?.content === "string" ? req.body.content.trim() : null;
  if (!content) {
    res.status(400).json({ error: "content is required and must be a non-empty string" });
    return;
  }
  if (content.length > 32_000) {
    res.status(400).json({ error: "content exceeds maximum length of 32000 characters" });
    return;
  }

  try {
    const conv = await getOwnedConversation(id, userId);
    if (!conv) { res.status(404).json({ error: "Conversation not found" }); return; }

    // Save user message
    await db.insert(messagesTable).values({ conversationId: id, role: "user", content });

    // Load full history for Gemini context
    const history = await db
      .select()
      .from(messagesTable)
      .where(eq(messagesTable.conversationId, id))
      .orderBy(asc(messagesTable.createdAt));

    // Set SSE headers before streaming
    res.setHeader("Content-Type", "text/event-stream");
    res.setHeader("Cache-Control", "no-cache");
    res.setHeader("Connection", "keep-alive");
    res.setHeader("X-Accel-Buffering", "no"); // disable nginx buffering

    // Detect client disconnect
    let clientGone = false;
    req.on("close", () => { clientGone = true; });

    let fullResponse = "";

    try {
      const stream = await ai.models.generateContentStream({
        model: "gemini-2.5-flash",
        contents: history.map((m) => ({
          role: m.role === "assistant" ? "model" : ("user" as "model" | "user"),
          parts: [{ text: m.content }],
        })),
        config: { maxOutputTokens: 8192, temperature: 0.7 },
      });

      for await (const chunk of stream) {
        if (clientGone) break;
        const text = chunk.text;
        if (text) {
          fullResponse += text;
          res.write(`data: ${JSON.stringify({ content: text })}\n\n`);
        }
      }

      // Persist assistant reply (even if client disconnected — keep history complete)
      if (fullResponse) {
        await db.insert(messagesTable).values({
          conversationId: id,
          role: "assistant",
          content: fullResponse,
        });
      }

      if (!clientGone) {
        res.write(`data: ${JSON.stringify({ done: true })}\n\n`);
        res.end();
      }
    } catch (streamErr) {
      req.log.error({ err: streamErr }, "Gemini streaming error");
      if (!clientGone) {
        res.write(`data: ${JSON.stringify({ error: "AI service error. Please try again." })}\n\n`);
        res.end();
      }
    }
  } catch (err) {
    req.log.error({ err }, "Failed to process message");
    if (!res.headersSent) {
      res.status(500).json({ error: "Internal server error" });
    }
  }
});

export default router;
